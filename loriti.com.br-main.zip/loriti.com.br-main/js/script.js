const menuToggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('.menu');
const menuOverlay = document.querySelector('.menu-overlay');
const body = document.body;

function openMenu() {
  if (!menuToggle || !menu) return;
  menu.classList.add('active');
  menuToggle.classList.add('open');
  menuToggle.setAttribute('aria-expanded', 'true');
  body.classList.add('menu-open');
  if (menuOverlay) menuOverlay.classList.add('active');
}

function closeMenu() {
  if (!menuToggle || !menu) return;
  menu.classList.remove('active');
  menuToggle.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  body.classList.remove('menu-open');
  if (menuOverlay) menuOverlay.classList.remove('active');
}

function toggleMenu() {
  if (!menu || !menu.classList.contains('active')) {
    openMenu();
  } else {
    closeMenu();
  }
}

if (menuToggle && menu) {
  menuToggle.addEventListener('click', toggleMenu);

  document.querySelectorAll('.menu a').forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  if (menuOverlay) {
    menuOverlay.addEventListener('click', closeMenu);
  }

  window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeMenu();
    }
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
      closeMenu();
    }
  });
}
